package com.youlu.api.model.db;

import lombok.Data;

@Data
public class InitTable {
    private String name;
}
