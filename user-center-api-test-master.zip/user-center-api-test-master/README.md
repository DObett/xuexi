设置环境变量 
API_HOST=http://192.168.11.206:8081/apiservice
DB_URL=jdbc:mysql://192.168.10.209:3306/talentbank