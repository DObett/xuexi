package com.niceloo;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.junit.Assert.*;

public class StepDefinitions {

    @Given("科目专业类型状态 {string}")
    public void getubjectMajorstype(String subjectMajorstype) {
        System.out.println("subjectMajorstype = " + subjectMajorstype);
    }

    @Given("科目展示状态 {string}")
    public void getsubjectShowstatus(String subjectShowstatus) {
        System.out.println("subjectShowstatus = " + subjectShowstatus);
    }


    @When("发起接口测试")
    public void sendReq(){
        //真正调用接口
        System.out.println("真正调用接口");
    }


    @Then("断言 {string}={string}")
    public void assertRes(String aName,String aValue){

    }
}
